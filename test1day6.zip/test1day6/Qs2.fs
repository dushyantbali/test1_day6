let rec sumMultiplesOf3 n =
    if n = 0 then 0
    else n + sumMultiplesOf3 (n - 3)

// Example usage
let result = sumMultiplesOf3 27
printfn "Sum of multiples of 3 up to 27: %d" result