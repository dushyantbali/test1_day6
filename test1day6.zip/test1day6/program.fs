
let salaries = [75000; 48000; 120000; 190000; 300113; 92000; 36000]

let highIncomeSalaries = salaries |> List.filter (fun salary -> salary > 100000)

let calculateTax salary =
    match salary with
    | _ when salary <= 49020 -> 0.1 * float salary
    | _ when salary <= 98040 -> 0.2 * float salary
    | _ -> 0.3 * float salary

let taxes = salaries |> List.map calculateTax

let updatedSalaries = 
    salaries 
    |> List.map (fun salary -> if salary < 49020 then salary + 20000 else salary)

let sumMidRangeSalaries =
    salaries
    |> List.filter (fun salary -> salary >= 50000 && salary <= 100000)
    |> List.reduce (+)

printfn "salaries :%A" salaries 
printfn "High-Income Salaries: %A" highIncomeSalaries
printfn "salaries :%A" salaries
printfn "Taxes for Salaries: %A" taxes
printfn "salaries :%A" salaries
printfn "Updated Salaries: %A" updatedSalaries
printfn "salaries :%A" salaries
printfn "Sum of Mid-Range Salaries: %d" sumMidRangeSalaries

// Part 2: Tail Recursion
let sumOfMultiplesOf3 limit =
    let rec sumHelper current acc =
        if current > limit then acc
        else sumHelper (current + 3) (acc + current)
    sumHelper 3 0


let result = sumOfMultiplesOf3 27
printfn "Sum of multiples of 3 up to 27: %d" result