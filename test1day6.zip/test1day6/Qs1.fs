// Part 1: Mapping, Filtering through Lists
let salaries = [75000; 48000; 120000; 190000; 300113; 92000; 36000]

// Filter salaries above $100,000 (high-income)
let highIncomeSalaries = salaries |> List.filter (fun salary -> salary > 100000)

// Function to calculate tax based on the salary range
let calculateTax salary =
    match salary with
    | _ when salary <= 49020 -> 0.1 * float salary
    | _ when salary <= 98040 -> 0.2 * float salary
    | _ -> 0.3 * float salary

// Map function to calculate taxes for all salaries
let taxes = salaries |> List.map calculateTax

// Add $20,000 to salaries less than $49,020
let updatedSalaries = 
    salaries 
    |> List.map (fun salary -> if salary < 49020 then salary + 20000 else salary)

// Sum salaries between $50,000 and $100,000 using reduce
let sumMidRangeSalaries =
    salaries
    |> List.filter (fun salary -> salary >= 50000 && salary <= 100000)
    |> List.reduce (+)

// Display results for Part 1
printfn "High-Income Salaries: %A" highIncomeSalaries
printfn "Taxes for Salaries: %A" taxes
printfn "Updated Salaries: %A" updatedSalaries
printfn "Sum of Mid-Range Salaries: %d" sumMidRangeSalaries
